"""
Distributive maker
"""
from distutils.core import setup

setup(name='Watch_It',
      version='1.0.0',
      description="Recommendation system",
      author="Film Scientists",
      package_dir={'main': 'watch_it/files',
                   "scripts": 'watch_it',
                   "data": 'watch_it/files/data',
                   "data_structure": 'watch_it/files/data_structure',
                   "test": 'watch_it/files/tests'},
      py_modules={"scripts.script"},
      packages=["main", "scripts", "data", "data_structure", "test"],
      package_data={'data': ['*.csv', '*.py', '*.txt', "test_only/*.csv", "test_only/*.py"]})
