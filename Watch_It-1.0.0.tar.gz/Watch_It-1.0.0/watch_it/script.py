"""
Run the application
"""
import os

os.system('python req.py')

from files.film_system import FilmSystem


if __name__ == "__main__":
    FilmSystem().menu()
