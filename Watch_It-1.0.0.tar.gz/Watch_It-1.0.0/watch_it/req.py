"""
Download libraries if needed
"""


import os
try:
    import pandas as pd
    import numpy as np
    import scipy as sc
except ImportError:
    os.system('pip install pandas')
    os.system('pip install numpy')
    os.system('pip install scipy')
else:
    LIBS = [pd, np, sc]
