"""
Test all modules
"""
import unittest
import os

os.system('python req.py')

from files.tests import test_data_structure, \
     test_matrix, \
     test_auth, \
     test_neighbour, \
     test_recomendation_engine, \
     test_start


class Test(unittest.TestCase):
    """
    Represent tester
    """

    @staticmethod
    def test_ds():
        """
        Test Data Structure
        """
        print("\n-----------Test Data Structure------------")
        test_data_structure.main()
        print("--------Passed Test Data Structure--------\n")

    @staticmethod
    def test_matrix_alg():
        """
        Test MATRIX Algorithm
        """
        print("\n-----------Test Matrix Algorithm------------")
        test_matrix.main()
        print("--------Passed Test Matrix Algorithm--------\n")

    @staticmethod
    def test_neighbour_alg():
        """
        Test NEAREST_NEIGHBOUR Algorithm
        """
        print("\n-----------Test Neighbour Algorithm------------")
        test_neighbour.main()
        print("--------Passed Test Neighbour Algorithm--------\n")

    @staticmethod
    def test_auth():
        """
        Test auth module
        """
        print("\n-------------------Test Auth-------------------")
        test_auth.main()
        print("----------------Passed Test Auth----------------\n")

    @staticmethod
    def test_rec():
        """
        Test recommendation_engine.py module
        """
        print("\n-----------Test Recommendation Engine-----------")
        test_recomendation_engine.main()
        print("-------Passed Test Recommendation Engine--------\n")

    @staticmethod
    def test_start():
        """
        Test start.py module
        """
        print("\n---------------Test Start Module----------------")
        test_start.main()
        print("------------Passed Test Start Module------------\n")


if __name__ == "__main__":
    unittest.main()
