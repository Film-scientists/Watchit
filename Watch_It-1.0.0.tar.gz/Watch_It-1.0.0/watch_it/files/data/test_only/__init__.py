"""
Some config
"""
import pathlib
CONFIG = str(pathlib.Path(__file__).parent.absolute())

RATINGS = CONFIG + "/ratings_test.csv"
MOVIES = CONFIG + "/movies_test.csv"
TEST = CONFIG + "/test.csv"
