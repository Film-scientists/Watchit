"""
Some config
"""
import pathlib
CONFIG = str(pathlib.Path(__file__).parent.absolute())

FINAL = CONFIG + "/final_ratings_2.csv"
MOVIES = CONFIG + "/movies.csv"
RATINGS = CONFIG + "/ratings_1M.csv"
USERS = CONFIG + "/users.txt"
