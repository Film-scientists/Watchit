"""
Some config
"""
from ..start import main
from ..matrix import matrix_fct
from ..neighbour import nearest_n
from ..recomendation_engine import core
from ..data_structure.data_structure import Saber
