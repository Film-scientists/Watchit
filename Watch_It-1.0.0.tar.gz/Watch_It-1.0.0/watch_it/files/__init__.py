"""
Some config
"""
import pathlib
from .data_structure import Saber

CONFIG = str(pathlib.Path(__file__).parent.absolute())

USERS = CONFIG + "/users.txt"
